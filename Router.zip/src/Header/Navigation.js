import React from "react";
import { Link } from "react-router-dom";

function Navigation() {
    return (
      <nav class="navbar navbar-expand-sm bg-dark">

      <div class="container-fluid">
    <ul class="navbar-nav">
      <Link to="/"><li><img src="https://www.achieversit.com/assets/images/logo-white.png" alt="AchieversIT Software Training Institute in Bangalore"/></li></Link>
    <li class="nav-item">
        <Link className="nav-link p-4" to="/">Home</Link>
      </li>
      <li class="nav-item">
        <Link className="nav-link p-4" to="/aboutus">About Us</Link>
      </li>
      <li class="nav-item">
        <Link class="nav-link p-4" to="/services">Services</Link>
      </li>
      <li class="nav-item">
        <Link class="nav-link p-4" to="/blog">Blog</Link>
      </li>
      <li class="nav-item">
        <Link class="nav-link p-4" to="/contactus">Contact Us</Link>
      </li>
    </ul>

<div>
<Link class="btn btn-info mx-4" to="/login">Login</Link>
    <Link class="btn btn-info" to="/contactus">Register</Link>
</div>

   
            
        </div>
        </nav>
    )
}

export default Navigation
