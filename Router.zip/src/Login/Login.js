import React from "react";

class Login extends React.Component {
    state={
        userName :'',
        password : '',
        userNameerr :'',
        passworderr : '',
    }

    handleChange =(e)=> {
     //console.log(e.target);
     const {name,value} = e.target;
     console.log(name,value);
     this.setState({[name]:value})
     console.log(this.state);
    }
    handleSubmit =(e) => {
        e.preventDefault();
       // console.log(this.state);
       this.validate();
    }

    validate =()=>{
        let userNameerr = "";
        let passworderr = "";

        if(this.state.userName.length<4) {
            userNameerr = "User Name should be minimum 4 character";
        }

        
        if(this.state.password.length<4) {
            passworderr = "Password should be minimum 4 character";
        }


        if(userNameerr || passworderr){
            this.setState({userNameerr,passworderr});
        }
    }
  render(){
    return (
        <div>
           <form className="login-form form-group m-auto p-3 w-50" onSubmit={this.handleSubmit}>
                <input
                  className="form-control w-50 mx-3 mt-3 mb-3"
                  type="text"
                  name="userName"
                  placeholder="Enter your User Name"
                onChange={this.handleChange}/>
                <p className="text-danger mx-3">{this.state.userNameerr}</p>
                <input
                  className="form-control w-50 mx-3 mt-3 mb-3"
                  type="password"
                  name="password"
                  placeholder="Enter your Password"
                  onChange={this.handleChange}
                />
                <p className="text-danger mx-3">{this.state.passworderr}</p>
                <button
                  className="btn btn-info mx-3 mt-3 mb-3"
                >Login</button>
              </form>
        </div>
    )
  }

}

export default Login;

