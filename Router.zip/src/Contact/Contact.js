import React from "react";

class Contact extends React.Component {
    state={
        firstName :'',
        lastName : '',
        email : '',
        password : '',
        firstNameerr :'',
        lastNameerr: '',
        emailerr : '',
        passworderr : '',
    }

    handleChange =(e)=> {
     //console.log(e.target);
     const {name,value} = e.target;
     console.log(name,value);
     this.setState({[name]:value})
     console.log(this.state);
    }
    handleSubmit =(e) => {
        e.preventDefault();
       // console.log(this.state);
       this.validate();
    }

    validate =()=>{
        let firstNameerr = "";
        let lastNameerr = "";
        let emailerr = "";
        let passworderr = "";
        if(this.state.firstName.length<4) {
            firstNameerr = "First Name should be minimum 4 character";
        }
        if(this.state.lastName.length<4) {
            lastNameerr = "Last Name should be minimum 4 character";
        }
        
        if(!this.state.email.includes('@')) {
           emailerr = "Enter a valid email";
        }

        if(this.state.password.length<4) {
            passworderr = "Password should be minimum 4 character";
        }

        if(firstNameerr || lastNameerr || emailerr || passworderr){
            this.setState({firstNameerr,lastNameerr,emailerr,passworderr});
        }
    }
    render() {
        return (
            <div>
              <form className="contact-form form-group m-auto p-3 w-50" onSubmit={this.handleSubmit}>
                <input
                  className="form-control mx-3 mt-3 mb-3"
                  type="text"
                  name="firstName"
                  placeholder="Enter your First Name"
                onChange={this.handleChange}/>
                <p className="text-danger mx-4">{this.state.firstNameerr}</p>
                <input
                  className="form-control mx-3 mt-3 mb-3"
                  type="text"
                  name="lastName"
                  placeholder="Enter your Last Name"
                  onChange={this.handleChange}
                />
                 <p className="text-danger mx-3">{this.state.lastNameerr}</p>
                <input
                  className="form-control mx-3 mt-3 mb-3"
                  type="email"
                  name="email"
                  placeholder="Enter your Email ID"
                  onChange={this.handleChange}
                />
                 <p className="text-danger mx-3">{this.state.emailerr}</p>
                <input
                  className="form-control mx-3 mt-3 mb-3"
                  type="password"
                  name="password"
                  placeholder="Enter your Password"
                  onChange={this.handleChange}
                />
                  <p className="text-danger mx-3">{this.state.passworderr}</p>
                <button
                  className="btn btn-info mx-3 mt-3 mb-3"
                >Register</button>
              </form>
            </div>
          );

    }

}

export default Contact;
