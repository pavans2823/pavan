import logo from './logo.svg';
import './App.css';
import Header from './Header/Header';
import Footer from './Footer/Footer';
import About from './About/About';
import Home from './Home/Home';
import Contact from './Contact/Contact';
import Login from './Login/Login';
import RoutesComponent from './Routes/RoutesComponent';
import React from 'react';
import Navigation from './Header/Navigation';
import 'bootstrap/dist/css/bootstrap.min.css';
import  './Footer/Footer.css';
import Services from './Services/Services';
import Blog from './Blog/Blog';


function App() {
  return (
    <div>
  
        <Navigation/>
        <RoutesComponent/>
        <Footer/>


    </div>
  );
}

export default App;
