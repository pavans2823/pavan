import React from "react";

function Services() {
    return (
        <div className='page-content text-center p-3'>
            Services Page Coming Soon
        </div>
    )
}

export default Services;

