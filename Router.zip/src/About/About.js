import React from "react";

function About() {
    return (
        <div className='page-content text-center p-3'>
            About Us  Coming Soon
        </div>
    )
}

export default About
