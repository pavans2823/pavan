import React from "react";
import Contact from "../Contact/Contact";
import About from "../About/About";
import Home from "../Home/Home";
import {Routes, Route} from "react-router-dom";
import Login from "../Login/Login";
import Services from "../Services/Services";
import Blog from "../Blog/Blog";


function RoutesComponent() {
    return (
    <Routes>
    <Route path="/" element={<Home/>} />
    <Route path="/aboutus" element={<About/>} />
    <Route path="/services" element={<Services/>} />
    <Route path="/blog" element={<Blog/>} />
    <Route path="/contactus" element={<Contact/>} />
    <Route path="/login" element={<Login/>} />
    </Routes>
    )
}

export default RoutesComponent
