import React from "react";

function Home() {
    return (
        <div className='page-content text-center p-3'>
            Home Page Coming Soon
        </div>
    )
}

export default Home;
