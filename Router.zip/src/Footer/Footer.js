import React from "react";

function Footer() {
    return (
        <div className='footer-content'>
            <p className='text-center m-auto p-3'>Footer Page Coming Soon</p>
        </div>
    )
}

export default Footer;

