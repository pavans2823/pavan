import React from "react";

function Blog() {
    return (
        <div className='page-content text-center p-3'>
            Blog Page Coming Soon
        </div>
    )
}

export default Blog;

